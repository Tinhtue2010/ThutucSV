<div class="w-100 mw-150px">
    <label class="form-label">Trạng thái</label>
    <select class="form-select  filter-select" data-name="status" data-control="select2" data-hide-search="true"
        data-placeholder="Trạng thái">
        <option></option>
        <option value="all">Hiển thị tất cả</option>
        <option value="0">Chưa xử lý</option>
        <option value="1">Đang xử lý</option>
        <option value="2">Hoàn tất xử lý</option>
    </select>
</div>